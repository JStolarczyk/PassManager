﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordChecker
{
    public partial class Form1 : Form
    {
        string Password_File = "saved_passwords.txt";
        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadDataIntoDataGridView(Password_File);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                string username = selectedRow.Cells["Username"].Value.ToString();
                string password = selectedRow.Cells["Password"].Value.ToString();

               

               // if (editForm.ShowDialog() == DialogResult.OK)
                {
                    // Update DataGridView with new values


                    SaveUpdatedData(); // Save after editing
                }
            }
            else
            {
                MessageBox.Show("Please select a row to edit.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
            }

            Form4 form4 = new Form4(dataGridView1); // Pass the reference of DataGridView to Form4
            form4.ShowDialog();
          
        }

        private void SaveUpdatedData()
        {
            using (StreamWriter writer = new StreamWriter(Password_File))
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (!row.IsNewRow) // Ignore empty row
                    {
                        string username = row.Cells["Username"].Value?.ToString() ?? "";
                        string password = row.Cells["Password"].Value?.ToString() ?? "";
                        writer.WriteLine($"{username},{password}");
                    }
                }
            }

        }

        private void LoadDataIntoDataGridView(string Password_File)
        {
            if (!File.Exists(Password_File))
            {
                MessageBox.Show(Password_File);
                return;
            }

            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();

            // Add columns to the DataGridView
            dataGridView1.Columns.Add("Username", "Username");
            dataGridView1.Columns.Add("Password", "Password");

            // Read and process file
            foreach (string line in File.ReadLines(Password_File))
            {
                string[] parts = line.Split(','); // Assuming CSV format (change delimiter if needed)
                if (parts.Length == 2)
                {
                    dataGridView1.Rows.Add(parts[0], parts[1]);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0) // Check if a row is selected
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (!row.IsNewRow) // Ensure it's not the empty new row
                    {
                        dataGridView1.Rows.Remove(row);
                    }
                }

                SaveUpdatedData(); // Save after deletion
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

        
    
}
    

