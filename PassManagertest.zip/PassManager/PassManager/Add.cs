﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace PassManager
{
    public partial class Add : Form
    {
        private DataGridView dgvLoginPairs;
        public Add(DataGridView dataGridView)
        {
            InitializeComponent();
            dgvLoginPairs = dataGridView; // Store the passed reference
        }



        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dt = dgvLoginPairs.DataSource as DataTable;
            if (dt != null)
            {
                DataRow row = dt.NewRow();
                row["Title"] = "1";
                row["Username"] = "1"; ;
                row["Password"] = "1"; ;
                dt.Rows.Add(row);
            }
        }

        private void Add_Load(object sender, EventArgs e)
        {

        }
    }
}
